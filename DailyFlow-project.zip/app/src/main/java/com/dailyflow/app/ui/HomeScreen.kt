@file:OptIn(ExperimentalFoundationApi::class)

package com.dailyflow.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.dailyflow.app.data.GroupEntity
import com.dailyflow.app.data.TaskEntity
import com.dailyflow.app.reminders.NotificationHelper
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private sealed interface DialogState {
    data object None : DialogState
    data object NewGroup : DialogState
    data class RenameGroup(val group: GroupEntity) : DialogState
    data class DeleteGroup(val group: GroupEntity, val taskCount: Int) : DialogState
    data class EditTask(val task: TaskEntity?, val defaultGroupId: Long) : DialogState
    data class DeleteTask(val task: TaskEntity) : DialogState
    data object Settings : DialogState
}

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val state by vm.state.collectAsState()
    val sortByTime by vm.settings.sortByTime.collectAsState()
    val themeMode by vm.settings.theme.collectAsState()
    val context = LocalContext.current

    var dialog by remember { mutableStateOf<DialogState>(DialogState.None) }

    // ----- Notification permission (Android 13+) -----
    var notificationsAllowed by remember { mutableStateOf(NotificationHelper.canPost(context)) }
    var openSettingsIfDenied by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsAllowed = NotificationHelper.canPost(context)
        if (!granted && openSettingsIfDenied) openAppNotificationSettings(context)
        openSettingsIfDenied = false
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                notificationsAllowed = NotificationHelper.canPost(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !notificationsAllowed && !vm.settings.askedNotificationPermission) {
            vm.settings.askedNotificationPermission = true
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val requestNotifications: () -> Unit = {
        val needsRuntimePermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsRuntimePermission) {
            openSettingsIfDenied = true
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            openAppNotificationSettings(context)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val first = state.groups.firstOrNull()
                    dialog = if (first == null) DialogState.NewGroup else DialogState.EditTask(null, first.group.id)
                },
                shape = RoundedCornerShape(20.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Add task")
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 104.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "header") {
                Header(date = state.date, onSettings = { dialog = DialogState.Settings })
            }
            if (!notificationsAllowed) {
                item(key = "notif_banner") {
                    NotificationBanner(onEnable = requestNotifications, modifier = Modifier.animateItem())
                }
            }
            item(key = "progress") {
                ProgressCard(done = state.done, total = state.total)
            }
            if (state.loaded && state.groups.isEmpty()) {
                item(key = "empty") {
                    EmptyState(onCreateGroup = { dialog = DialogState.NewGroup })
                }
            }
            state.groups.forEachIndexed { index, groupUi ->
                val group = groupUi.group
                item(key = "g_${group.id}") {
                    GroupHeader(
                        groupUi = groupUi,
                        isFirst = index == 0,
                        isLast = index == state.groups.lastIndex,
                        onToggleCollapse = { vm.setGroupCollapsed(group.id, !group.collapsed) },
                        onAddTask = { dialog = DialogState.EditTask(null, group.id) },
                        onRename = { dialog = DialogState.RenameGroup(group) },
                        onMoveUp = { vm.moveGroup(group.id, up = true) },
                        onMoveDown = { vm.moveGroup(group.id, up = false) },
                        onDelete = { dialog = DialogState.DeleteGroup(group, groupUi.tasks.size) },
                        modifier = Modifier.animateItem(),
                    )
                }
                if (!group.collapsed) {
                    if (groupUi.tasks.isEmpty()) {
                        item(key = "ge_${group.id}") {
                            EmptyGroupRow(
                                onAdd = { dialog = DialogState.EditTask(null, group.id) },
                                modifier = Modifier.animateItem(),
                            )
                        }
                    }
                    items(groupUi.tasks, key = { "t_${it.task.id}" }) { taskUi ->
                        val position = groupUi.tasks.indexOf(taskUi)
                        TaskRow(
                            taskUi = taskUi,
                            canReorder = !sortByTime,
                            isFirst = position == 0,
                            isLast = position == groupUi.tasks.lastIndex,
                            onToggle = { vm.setDone(taskUi.task.id, it) },
                            onEdit = { dialog = DialogState.EditTask(taskUi.task, group.id) },
                            onMoveUp = { vm.moveTask(taskUi.task.id, up = true) },
                            onMoveDown = { vm.moveTask(taskUi.task.id, up = false) },
                            onDelete = { dialog = DialogState.DeleteTask(taskUi.task) },
                            modifier = Modifier.animateItem(),
                        )
                    }
                }
            }
            if (state.groups.isNotEmpty()) {
                item(key = "add_group") {
                    TextButton(
                        onClick = { dialog = DialogState.NewGroup },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .animateItem(),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("New group")
                    }
                }
            }
        }
    }

    // ----- Dialogs -----
    when (val d = dialog) {
        DialogState.None -> Unit
        DialogState.NewGroup -> NameDialog(
            title = "New group",
            initial = "",
            confirmLabel = "Create",
            onConfirm = { vm.addGroup(it); dialog = DialogState.None },
            onDismiss = { dialog = DialogState.None },
        )
        is DialogState.RenameGroup -> NameDialog(
            title = "Rename group",
            initial = d.group.name,
            confirmLabel = "Save",
            onConfirm = { vm.renameGroup(d.group.id, it); dialog = DialogState.None },
            onDismiss = { dialog = DialogState.None },
        )
        is DialogState.DeleteGroup -> ConfirmDialog(
            title = "Delete \"${d.group.name}\"?",
            text = if (d.taskCount == 0) "This group is empty." else
                "This also deletes its ${d.taskCount} task${if (d.taskCount == 1) "" else "s"} and their reminders.",
            confirmLabel = "Delete",
            onConfirm = { vm.deleteGroup(d.group.id); dialog = DialogState.None },
            onDismiss = { dialog = DialogState.None },
        )
        is DialogState.EditTask -> TaskEditorDialog(
            initial = d.task,
            groups = state.groups.map { it.group },
            defaultGroupId = d.defaultGroupId,
            onSave = { title, groupId, hour, minute, reminder ->
                vm.saveTask(d.task?.id, groupId, title, hour, minute, reminder)
                dialog = DialogState.None
            },
            onDelete = if (d.task != null) {
                { dialog = DialogState.DeleteTask(d.task) }
            } else {
                null
            },
            onDismiss = { dialog = DialogState.None },
        )
        is DialogState.DeleteTask -> ConfirmDialog(
            title = "Delete task?",
            text = "\"${d.task.title}\" and its reminder will be removed.",
            confirmLabel = "Delete",
            onConfirm = { vm.deleteTask(d.task.id); dialog = DialogState.None },
            onDismiss = { dialog = DialogState.None },
        )
        DialogState.Settings -> SettingsDialog(
            themeMode = themeMode,
            onThemeChange = { vm.settings.setTheme(it) },
            sortByTime = sortByTime,
            onSortChange = { vm.settings.setSortByTime(it) },
            notificationsAllowed = notificationsAllowed,
            onEnableNotifications = requestNotifications,
            onDismiss = { dialog = DialogState.None },
        )
    }
}

fun openAppNotificationSettings(context: Context) {
    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(android.net.Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(fallback)
        } catch (ignored: Exception) {
        }
    }
}

// ---------------------------------------------------------------------------
// Pieces of the home screen
// ---------------------------------------------------------------------------

@Composable
private fun Header(date: LocalDate, onSettings: () -> Unit) {
    val locale = Locale.getDefault()
    val dayName = date.format(DateTimeFormatter.ofPattern("EEEE", locale))
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }
    val fullDate = date.format(DateTimeFormatter.ofPattern("d MMMM yyyy", locale))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = dayName,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = fullDate,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        IconButton(onClick = onSettings) {
            Icon(
                Icons.Rounded.Settings,
                contentDescription = "Settings",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ProgressCard(done: Int, total: Int) {
    val fraction = if (total == 0) 0f else done.toFloat() / total
    val animated by animateFloatAsState(fraction, animationSpec = tween(700), label = "progress")
    val colors = MaterialTheme.colorScheme
    val message = when {
        total == 0 -> "Add your first task to get started"
        done == 0 -> "Let's get started!"
        done == total -> "All done for today. Great job! 🎉"
        fraction >= 0.5f -> "More than halfway there!"
        else -> "Nice start, keep going!"
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(colors.primary, colors.tertiary)))
            .padding(horizontal = 22.dp, vertical = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Today's progress",
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.onPrimary.copy(alpha = 0.8f),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (total == 0) "No tasks yet" else "$done of $total done",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = colors.onPrimary,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onPrimary.copy(alpha = 0.85f),
                )
            }
            Spacer(Modifier.width(12.dp))
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(72.dp)) {
                CircularProgressIndicator(
                    progress = { animated },
                    modifier = Modifier.size(72.dp),
                    color = colors.onPrimary,
                    strokeWidth = 7.dp,
                    trackColor = colors.onPrimary.copy(alpha = 0.22f),
                    strokeCap = StrokeCap.Round,
                )
                Text(
                    text = "${(animated * 100).roundToInt()}%",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = colors.onPrimary,
                )
            }
        }
    }
}

@Composable
private fun NotificationBanner(onEnable: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer,
            contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        ),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Notifications, contentDescription = null)
            Spacer(Modifier.width(12.dp))
            Text(
                "Notifications are off, so reminders can't appear.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onEnable) { Text("Turn on") }
        }
    }
}

@Composable
private fun EmptyState(onCreateGroup: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp),
            )
        }
        Spacer(Modifier.height(16.dp))
        Text("Plan your day once", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(6.dp))
        Text(
            "Create a group like \"Morning Routine\", add tasks to it, and they will repeat every day. Checkmarks reset at midnight.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onCreateGroup, shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Create first group")
        }
    }
}

@Composable
private fun GroupHeader(
    groupUi: GroupUi,
    isFirst: Boolean,
    isLast: Boolean,
    onToggleCollapse: () -> Unit,
    onAddTask: () -> Unit,
    onRename: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val collapsed = groupUi.group.collapsed
    val rotation by animateFloatAsState(if (collapsed) -90f else 0f, label = "arrow")
    var menuOpen by remember { mutableStateOf(false) }
    val allDone = groupUi.tasks.isNotEmpty() && groupUi.doneCount == groupUi.tasks.size

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 12.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onToggleCollapse)
            .padding(start = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Rounded.KeyboardArrowDown,
            contentDescription = if (collapsed) "Expand" else "Collapse",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.rotate(rotation),
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = groupUi.group.name.uppercase(Locale.getDefault()),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Surface(
            shape = RoundedCornerShape(50),
            color = if (allDone) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        ) {
            Text(
                text = "${groupUi.doneCount}/${groupUi.tasks.size}",
                style = MaterialTheme.typography.labelMedium,
                color = if (allDone) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
            )
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(
                    Icons.Rounded.MoreVert,
                    contentDescription = "Group options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(text = { Text("Add task") }, onClick = { menuOpen = false; onAddTask() })
                DropdownMenuItem(text = { Text("Rename") }, onClick = { menuOpen = false; onRename() })
                DropdownMenuItem(
                    text = { Text("Move up") },
                    enabled = !isFirst,
                    onClick = { menuOpen = false; onMoveUp() },
                )
                DropdownMenuItem(
                    text = { Text("Move down") },
                    enabled = !isLast,
                    onClick = { menuOpen = false; onMoveDown() },
                )
                DropdownMenuItem(
                    text = { Text("Delete group", color = MaterialTheme.colorScheme.error) },
                    onClick = { menuOpen = false; onDelete() },
                )
            }
        }
    }
}

@Composable
private fun EmptyGroupRow(onAdd: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onAdd,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
    ) {
        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text("Add a task to this group")
    }
}

@Composable
private fun TaskRow(
    taskUi: TaskUi,
    canReorder: Boolean,
    isFirst: Boolean,
    isLast: Boolean,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val task = taskUi.task
    val done = taskUi.done
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    val titleColor by animateColorAsState(
        if (done) colors.onSurfaceVariant.copy(alpha = 0.7f) else colors.onSurface,
        label = "titleColor",
    )
    val cardColor by animateColorAsState(
        if (done) colors.surface.copy(alpha = 0.6f) else colors.surface,
        label = "cardColor",
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (done) 0.dp else 1.dp),
    ) {
        Box {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .combinedClickable(onClick = onEdit, onLongClick = { menuOpen = true })
                    .padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundCheckbox(checked = done, onCheckedChange = onToggle)
                Spacer(Modifier.width(6.dp))
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = titleColor,
                    textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 10.dp),
                )
                val hour = task.hour
                val minute = task.minute
                if (hour != null && minute != null) {
                    Spacer(Modifier.width(8.dp))
                    TimeChip(
                        text = NotificationHelper.formatTime(context, hour, minute),
                        reminderOn = task.reminderEnabled,
                        dimmed = done,
                    )
                }
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(text = { Text("Edit") }, onClick = { menuOpen = false; onEdit() })
                if (canReorder) {
                    DropdownMenuItem(
                        text = { Text("Move up") },
                        enabled = !isFirst,
                        onClick = { menuOpen = false; onMoveUp() },
                    )
                    DropdownMenuItem(
                        text = { Text("Move down") },
                        enabled = !isLast,
                        onClick = { menuOpen = false; onMoveDown() },
                    )
                } else {
                    DropdownMenuItem(
                        text = { Text("To reorder, turn off \"Sort by time\" in Settings") },
                        enabled = false,
                        onClick = {},
                    )
                }
                DropdownMenuItem(
                    text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                    onClick = { menuOpen = false; onDelete() },
                )
            }
        }
    }
}

@Composable
private fun TimeChip(text: String, reminderOn: Boolean, dimmed: Boolean) {
    val colors = MaterialTheme.colorScheme
    val container = if (reminderOn) colors.primaryContainer else colors.surfaceVariant
    val content = if (reminderOn) colors.onPrimaryContainer else colors.onSurfaceVariant
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = container.copy(alpha = if (dimmed) 0.5f else 1f),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (reminderOn) {
                Icon(
                    Icons.Rounded.Notifications,
                    contentDescription = "Reminder on",
                    tint = content.copy(alpha = if (dimmed) 0.6f else 1f),
                    modifier = Modifier.size(14.dp),
                )
                Spacer(Modifier.width(4.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                color = content.copy(alpha = if (dimmed) 0.6f else 1f),
            )
        }
    }
}

@Composable
private fun RoundCheckbox(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val colors = MaterialTheme.colorScheme
    val haptics = LocalHapticFeedback.current
    val fill by animateColorAsState(if (checked) colors.primary else colors.surface, label = "fill")
    val border by animateColorAsState(if (checked) colors.primary else colors.outline, label = "border")
    val checkScale by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "checkScale",
    )
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .toggleable(
                value = checked,
                role = Role.Checkbox,
                onValueChange = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onCheckedChange(it)
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(fill)
                .border(2.dp, border, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = colors.onPrimary,
                modifier = Modifier
                    .size(18.dp)
                    .graphicsLayer {
                        scaleX = checkScale
                        scaleY = checkScale
                        alpha = checkScale.coerceIn(0f, 1f)
                    },
            )
        }
    }
}
