package com.dailyflow.app.reminders

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.text.format.DateFormat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.dailyflow.app.MainActivity
import com.dailyflow.app.R
import com.dailyflow.app.data.TaskEntity
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object NotificationHelper {
    const val CHANNEL_ID = "task_reminders"
    private const val TEST_NOTIFICATION_ID = 1_999_999_998

    fun notificationId(taskId: Long): Int = (taskId % 1_000_000_000L).toInt()

    fun createChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        // Normal notification channel: uses the phone's own sound/vibration settings.
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = context.getString(R.string.channel_description)
        }
        manager.createNotificationChannel(channel)
    }

    fun canPost(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun formatTime(context: Context, hour: Int, minute: Int): String {
        val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm a"
        return LocalTime.of(hour, minute).format(DateTimeFormatter.ofPattern(pattern, Locale.getDefault()))
    }

    @SuppressLint("MissingPermission")
    fun showTaskReminder(context: Context, task: TaskEntity, groupName: String?) {
        if (!canPost(context)) return
        val id = notificationId(task.id)

        val doneIntent = Intent(context, ReminderReceiver::class.java)
            .setAction(ReminderReceiver.ACTION_DONE)
            .setData(Uri.parse("dailyflow://done/${task.id}"))
            .putExtra(ReminderReceiver.EXTRA_TASK_ID, task.id)
        val donePending = PendingIntent.getBroadcast(
            context,
            id,
            doneIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val hour = task.hour
        val minute = task.minute
        val details = listOfNotNull(
            if (hour != null && minute != null) formatTime(context, hour, minute) else null,
            groupName,
        ).joinToString(" · ")

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(task.title)
            .setContentText(details.ifEmpty { context.getString(R.string.reminder_default_text) })
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setColor(0xFF5B5BD6.toInt())
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .addAction(R.drawable.ic_check, context.getString(R.string.mark_done), donePending)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(id, notification)
        } catch (e: SecurityException) {
            // Permission was removed in the meantime; nothing to do.
        }
    }

    @SuppressLint("MissingPermission")
    fun showTest(context: Context) {
        if (!canPost(context)) return
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.test_title))
            .setContentText(context.getString(R.string.test_text))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setColor(0xFF5B5BD6.toInt())
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(TEST_NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
        }
    }

    fun cancel(context: Context, taskId: Long) {
        NotificationManagerCompat.from(context).cancel(notificationId(taskId))
    }

    private fun openAppIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }
}
