package com.dailyflow.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupDao {
    @Query("SELECT * FROM task_groups ORDER BY position ASC, id ASC")
    fun observeAll(): Flow<List<GroupEntity>>

    @Query("SELECT * FROM task_groups ORDER BY position ASC, id ASC")
    suspend fun getAll(): List<GroupEntity>

    @Query("SELECT * FROM task_groups WHERE id = :id")
    suspend fun getById(id: Long): GroupEntity?

    @Query("SELECT COALESCE(MAX(position), -1) FROM task_groups")
    suspend fun maxPosition(): Int

    @Insert
    suspend fun insert(group: GroupEntity): Long

    @Update
    suspend fun update(group: GroupEntity)

    @Update
    suspend fun updateAll(groups: List<GroupEntity>)

    @Query("DELETE FROM task_groups WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY position ASC, id ASC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks")
    suspend fun getAll(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: Long): TaskEntity?

    @Query("SELECT * FROM tasks WHERE groupId = :groupId ORDER BY position ASC, id ASC")
    suspend fun getByGroup(groupId: Long): List<TaskEntity>

    @Query("SELECT COALESCE(MAX(position), -1) FROM tasks WHERE groupId = :groupId")
    suspend fun maxPosition(groupId: Long): Int

    @Insert
    suspend fun insert(task: TaskEntity): Long

    @Update
    suspend fun update(task: TaskEntity)

    @Update
    suspend fun updateAll(tasks: List<TaskEntity>)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface CompletionDao {
    @Query("SELECT taskId FROM completions WHERE date = :date")
    fun observeDoneIds(date: String): Flow<List<Long>>

    @Query("SELECT COUNT(*) FROM completions WHERE taskId = :taskId AND date = :date")
    suspend fun count(taskId: Long, date: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(completion: CompletionEntity)

    @Query("DELETE FROM completions WHERE taskId = :taskId AND date = :date")
    suspend fun delete(taskId: Long, date: String)

    @Query("DELETE FROM completions WHERE date < :date")
    suspend fun deleteBefore(date: String)
}
