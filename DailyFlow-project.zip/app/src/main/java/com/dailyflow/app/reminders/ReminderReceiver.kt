package com.dailyflow.app.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dailyflow.app.data.Repository
import com.dailyflow.app.data.hasActiveReminder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.LocalDate

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val action = intent.action ?: return

        if (action == ACTION_TEST) {
            NotificationHelper.showTest(app)
            return
        }

        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        if (taskId < 0) return

        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                when (action) {
                    ACTION_FIRE -> handleFire(app, taskId, intent.getLongExtra(EXTRA_TRIGGER_AT, 0L))
                    ACTION_DONE -> Repository.get(app).setDone(taskId, LocalDate.now(), true)
                }
            } catch (e: Exception) {
                // Never crash in the background.
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun handleFire(context: Context, taskId: Long, triggerAt: Long) {
        val repo = Repository.get(context)
        val task = repo.taskDao.getById(taskId)
        if (task == null || !task.hasActiveReminder()) {
            ReminderScheduler.cancel(context, taskId)
            return
        }

        val now = System.currentTimeMillis()
        val tooLate = triggerAt > 0 && now - triggerAt > MAX_LATENESS_MS
        val alreadyDone = repo.isDone(taskId, LocalDate.now())
        if (!tooLate && !alreadyDone) {
            val groupName = repo.groupDao.getById(task.groupId)?.name
            NotificationHelper.showTaskReminder(context, task, groupName)
        }

        // Schedule tomorrow's reminder (strictly after this one, so never twice in a day).
        ReminderScheduler.schedule(context, task, afterMillis = maxOf(now, triggerAt) + 1_000L)
    }

    companion object {
        const val ACTION_FIRE = "com.dailyflow.app.action.REMINDER"
        const val ACTION_DONE = "com.dailyflow.app.action.MARK_DONE"
        const val ACTION_TEST = "com.dailyflow.app.action.TEST"
        const val EXTRA_TASK_ID = "task_id"
        const val EXTRA_TRIGGER_AT = "trigger_at"

        /** A reminder that arrives more than 3 hours late (phone was off) is skipped. */
        private const val MAX_LATENESS_MS = 3 * 60 * 60 * 1000L
    }
}
