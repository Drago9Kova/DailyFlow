package com.dailyflow.app

import android.app.Application
import com.dailyflow.app.reminders.MaintenanceWorker
import com.dailyflow.app.reminders.NotificationHelper

class DailyFlowApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)
        MaintenanceWorker.enqueue(this)
    }
}
