package com.dailyflow.app.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.dailyflow.app.data.Repository
import com.dailyflow.app.data.TaskEntity
import com.dailyflow.app.data.hasActiveReminder
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Schedules one alarm per task for its next reminder time. When it fires,
 * [ReminderReceiver] shows the notification and schedules the next day.
 *
 * Uses AlarmManager.setAndAllowWhileIdle: works when the app is closed and the
 * phone is locked, needs no special permission, and is not an alarm clock.
 * Android may delay it by a few minutes to save battery.
 */
object ReminderScheduler {

    /** If a reminder time passed less than this long ago, its alarm may still be on its way. */
    private const val RECENT_WINDOW_MS = 60 * 60 * 1000L
    private const val TEST_REQUEST_CODE = 1_999_999_999

    fun nextTrigger(hour: Int, minute: Int, afterMillis: Long, zone: ZoneId = ZoneId.systemDefault()): ZonedDateTime {
        val after = Instant.ofEpochMilli(afterMillis).atZone(zone)
        val time = LocalTime.of(hour, minute)
        // ZonedDateTime.of handles daylight saving time: a time that does not exist
        // (clocks jump forward) is moved later, and a repeated time uses the first one.
        var candidate = ZonedDateTime.of(after.toLocalDate(), time, zone)
        if (!candidate.isAfter(after)) {
            candidate = ZonedDateTime.of(after.toLocalDate().plusDays(1), time, zone)
        }
        return candidate
    }

    fun schedule(context: Context, task: TaskEntity, afterMillis: Long = System.currentTimeMillis()) {
        val hour = task.hour
        val minute = task.minute
        if (!task.hasActiveReminder() || hour == null || minute == null) {
            cancel(context, task.id)
            return
        }
        val triggerAt = nextTrigger(hour, minute, afterMillis).toInstant().toEpochMilli()
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
        // Same request code + same intent = the old alarm is replaced, never duplicated.
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerAt,
            reminderIntent(context, task.id, triggerAt),
        )
    }

    fun cancel(context: Context, taskId: Long) {
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = reminderIntent(context, taskId, 0L)
        alarmManager.cancel(pi)
        pi.cancel()
    }

    /**
     * Makes sure every task with a reminder has an alarm. Safe to call often.
     * With [force] = false, a task whose time passed in the last hour is left alone,
     * so a reminder that is still on its way is not skipped.
     */
    suspend fun rescheduleAll(context: Context, force: Boolean) {
        val tasks = Repository.get(context).taskDao.getAll()
        val zone = ZoneId.systemDefault()
        val now = System.currentTimeMillis()
        val today = LocalDate.now(zone)
        for (task in tasks) {
            val hour = task.hour
            val minute = task.minute
            if (!task.hasActiveReminder() || hour == null || minute == null) {
                cancel(context, task.id)
                continue
            }
            if (!force) {
                val todayAt = ZonedDateTime.of(today, LocalTime.of(hour, minute), zone)
                    .toInstant().toEpochMilli()
                if (now >= todayAt && now - todayAt < RECENT_WINDOW_MS) continue
            }
            schedule(context, task, now)
        }
    }

    /** Test reminder that arrives in about one minute, even with the app closed. */
    fun scheduleTest(context: Context) {
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
        val intent = Intent(context, ReminderReceiver::class.java)
            .setAction(ReminderReceiver.ACTION_TEST)
        val pi = PendingIntent.getBroadcast(
            context,
            TEST_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + 60_000L,
            pi,
        )
    }

    private fun reminderIntent(context: Context, taskId: Long, triggerAt: Long): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
            .setAction(ReminderReceiver.ACTION_FIRE)
            .setData(Uri.parse("dailyflow://reminder/$taskId"))
            .putExtra(ReminderReceiver.EXTRA_TASK_ID, taskId)
            .putExtra(ReminderReceiver.EXTRA_TRIGGER_AT, triggerAt)
        return PendingIntent.getBroadcast(
            context,
            NotificationHelper.notificationId(taskId),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }
}
