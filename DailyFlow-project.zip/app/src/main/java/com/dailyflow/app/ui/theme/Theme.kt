package com.dailyflow.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B5BD6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3E2FF),
    onPrimaryContainer = Color(0xFF17155F),
    secondary = Color(0xFF23998B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD4F3EE),
    onSecondaryContainer = Color(0xFF00382F),
    tertiary = Color(0xFF9B6CEF),
    onTertiary = Color.White,
    background = Color(0xFFF4F5FA),
    onBackground = Color(0xFF1A1B23),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1B23),
    surfaceVariant = Color(0xFFE9EAF2),
    onSurfaceVariant = Color(0xFF5E6072),
    surfaceTint = Color(0xFF5B5BD6),
    outline = Color(0xFFC2C4D2),
    outlineVariant = Color(0xFFE1E2EA),
    error = Color(0xFFD13C4A),
    onError = Color.White,
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8F8FC),
    surfaceContainer = Color(0xFFF7F7FC),
    surfaceContainerHigh = Color(0xFFF7F7FC),
    surfaceContainerHighest = Color(0xFFEDEEF5),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFAAA9FF),
    onPrimary = Color(0xFF1C1A6B),
    primaryContainer = Color(0xFF34338F),
    onPrimaryContainer = Color(0xFFE3E2FF),
    secondary = Color(0xFF72D8C8),
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF12443D),
    onSecondaryContainer = Color(0xFFB7F0E6),
    tertiary = Color(0xFFCDB6FF),
    onTertiary = Color(0xFF2E1170),
    background = Color(0xFF0F1016),
    onBackground = Color(0xFFE5E5EE),
    surface = Color(0xFF1A1B24),
    onSurface = Color(0xFFE5E5EE),
    surfaceVariant = Color(0xFF2A2B36),
    onSurfaceVariant = Color(0xFFA6A8B8),
    surfaceTint = Color(0xFFAAA9FF),
    outline = Color(0xFF4C4E5E),
    outlineVariant = Color(0xFF2E303B),
    error = Color(0xFFFF8A94),
    onError = Color(0xFF5C0010),
    surfaceContainerLowest = Color(0xFF0B0C11),
    surfaceContainerLow = Color(0xFF16171F),
    surfaceContainer = Color(0xFF1F2029),
    surfaceContainerHigh = Color(0xFF22232D),
    surfaceContainerHighest = Color(0xFF2B2C37),
)

private val AppTypography = Typography().let { base ->
    base.copy(
        headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    )
}

@Composable
fun DailyFlowTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
