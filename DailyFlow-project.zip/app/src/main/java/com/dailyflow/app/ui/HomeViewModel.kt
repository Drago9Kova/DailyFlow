package com.dailyflow.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dailyflow.app.data.GroupEntity
import com.dailyflow.app.data.Repository
import com.dailyflow.app.data.SettingsStore
import com.dailyflow.app.data.TaskEntity
import com.dailyflow.app.data.minutesOfDay
import com.dailyflow.app.reminders.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

data class TaskUi(val task: TaskEntity, val done: Boolean)

data class GroupUi(val group: GroupEntity, val tasks: List<TaskUi>) {
    val doneCount: Int get() = tasks.count { it.done }
}

data class HomeState(
    val date: LocalDate = LocalDate.now(),
    val groups: List<GroupUi> = emptyList(),
    val total: Int = 0,
    val done: Int = 0,
    val loaded: Boolean = false,
)

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository.get(app)
    val settings = SettingsStore.get(app)

    /** The current local date. Checkmarks are read for this date only. */
    private val today = MutableStateFlow(LocalDate.now())

    private val doneForToday = today.flatMapLatest { date ->
        repo.observeDoneIds(date).map { ids -> date to ids.toSet() }
    }

    val state: StateFlow<HomeState> = combine(
        repo.observeGroups(),
        repo.observeTasks(),
        doneForToday,
        settings.sortByTime,
    ) { groups, tasks, dateAndDone, sortByTime ->
        val (date, doneIds) = dateAndDone
        val tasksByGroup = tasks.groupBy { it.groupId }
        val groupUis = groups.map { group ->
            val list = tasksByGroup[group.id].orEmpty()
            val sorted = if (sortByTime) {
                list.sortedWith(
                    compareBy<TaskEntity>({ it.minutesOfDay() ?: Int.MAX_VALUE }, { it.position }, { it.id })
                )
            } else {
                list.sortedWith(compareBy<TaskEntity>({ it.position }, { it.id }))
            }
            GroupUi(group, sorted.map { TaskUi(it, it.id in doneIds) })
        }
        HomeState(
            date = date,
            groups = groupUis,
            total = tasks.size,
            done = tasks.count { it.id in doneIds },
            loaded = true,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    init {
        // Switch to the new day at midnight while the app is open.
        viewModelScope.launch {
            while (true) {
                val now = LocalDateTime.now()
                val nextMidnight = now.toLocalDate().plusDays(1).atStartOfDay()
                val waitMs = Duration.between(now, nextMidnight).toMillis().coerceAtLeast(0L) + 1_000L
                delay(waitMs.coerceAtMost(15 * 60 * 1000L))
                refreshDate()
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            ReminderScheduler.rescheduleAll(app, force = false)
            repo.pruneOldCompletions()
        }
    }

    /** Called when the app comes back to the screen (e.g. the next morning). */
    fun refreshDate() {
        val now = LocalDate.now()
        if (now != today.value) today.value = now
    }

    private fun io(block: suspend () -> Unit) {
        viewModelScope.launch { withContext(Dispatchers.IO) { block() } }
    }

    fun setDone(taskId: Long, done: Boolean) {
        refreshDate()
        val date = today.value
        io { repo.setDone(taskId, date, done) }
    }

    fun addGroup(name: String) = io { repo.addGroup(name) }
    fun renameGroup(id: Long, name: String) = io { repo.renameGroup(id, name) }
    fun deleteGroup(id: Long) = io { repo.deleteGroup(id) }
    fun moveGroup(id: Long, up: Boolean) = io { repo.moveGroup(id, up) }
    fun setGroupCollapsed(id: Long, collapsed: Boolean) = io { repo.setGroupCollapsed(id, collapsed) }

    fun saveTask(id: Long?, groupId: Long, title: String, hour: Int?, minute: Int?, reminder: Boolean) =
        io { repo.saveTask(id, groupId, title, hour, minute, reminder) }

    fun deleteTask(id: Long) = io { repo.deleteTask(id) }
    fun moveTask(id: Long, up: Boolean) = io { repo.moveTask(id, up) }
}
