package com.dailyflow.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "task_groups")
data class GroupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val position: Int,
    val collapsed: Boolean = false,
)

@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = GroupEntity::class,
            parentColumns = ["id"],
            childColumns = ["groupId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index("groupId")],
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupId: Long,
    val title: String,
    val hour: Int? = null,
    val minute: Int? = null,
    val reminderEnabled: Boolean = false,
    val position: Int = 0,
)

/**
 * One row = "this task was completed on this calendar date".
 * Because completion is stored per date, a new day automatically shows every
 * task unchecked again. The tasks themselves are never touched.
 */
@Entity(
    tableName = "completions",
    primaryKeys = ["taskId", "date"],
    foreignKeys = [
        ForeignKey(
            entity = TaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["taskId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index("taskId"), Index("date")],
)
data class CompletionEntity(
    val taskId: Long,
    /** Local date in ISO format, e.g. 2026-11-21. */
    val date: String,
)

fun TaskEntity.hasTime(): Boolean = hour != null && minute != null

fun TaskEntity.minutesOfDay(): Int? {
    val h = hour ?: return null
    val m = minute ?: return null
    return h * 60 + m
}

fun TaskEntity.hasActiveReminder(): Boolean = reminderEnabled && hasTime()
