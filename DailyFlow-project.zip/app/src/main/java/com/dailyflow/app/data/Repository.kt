package com.dailyflow.app.data

import android.content.Context
import androidx.room.withTransaction
import com.dailyflow.app.reminders.NotificationHelper
import com.dailyflow.app.reminders.ReminderScheduler
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class Repository private constructor(private val context: Context) {
    private val db = AppDatabase.get(context)
    val groupDao = db.groupDao()
    val taskDao = db.taskDao()
    val completionDao = db.completionDao()

    fun observeGroups(): Flow<List<GroupEntity>> = groupDao.observeAll()
    fun observeTasks(): Flow<List<TaskEntity>> = taskDao.observeAll()
    fun observeDoneIds(date: LocalDate): Flow<List<Long>> = completionDao.observeDoneIds(date.toString())

    // ---------- Groups ----------

    suspend fun addGroup(name: String): Long {
        val clean = name.trim()
        if (clean.isEmpty()) return -1
        return groupDao.insert(GroupEntity(name = clean, position = groupDao.maxPosition() + 1))
    }

    suspend fun renameGroup(id: Long, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        val group = groupDao.getById(id) ?: return
        groupDao.update(group.copy(name = clean))
    }

    suspend fun setGroupCollapsed(id: Long, collapsed: Boolean) {
        val group = groupDao.getById(id) ?: return
        groupDao.update(group.copy(collapsed = collapsed))
    }

    suspend fun deleteGroup(id: Long) {
        // Stop reminders of every task in the group before the database removes them.
        taskDao.getByGroup(id).forEach { task ->
            ReminderScheduler.cancel(context, task.id)
            NotificationHelper.cancel(context, task.id)
        }
        groupDao.deleteById(id)
    }

    suspend fun moveGroup(id: Long, up: Boolean) {
        db.withTransaction {
            val list = groupDao.getAll().toMutableList()
            val from = list.indexOfFirst { it.id == id }
            val to = if (up) from - 1 else from + 1
            if (from < 0 || to !in list.indices) return@withTransaction
            val item = list.removeAt(from)
            list.add(to, item)
            groupDao.updateAll(list.mapIndexed { index, g -> g.copy(position = index) })
        }
    }

    // ---------- Tasks ----------

    suspend fun saveTask(
        id: Long?,
        groupId: Long,
        title: String,
        hour: Int?,
        minute: Int?,
        reminderEnabled: Boolean,
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isEmpty()) return
        val timeSet = hour != null && minute != null
        val h = if (timeSet) hour else null
        val m = if (timeSet) minute else null
        val reminder = reminderEnabled && timeSet

        val saved: TaskEntity = if (id == null) {
            val task = TaskEntity(
                groupId = groupId,
                title = cleanTitle,
                hour = h,
                minute = m,
                reminderEnabled = reminder,
                position = taskDao.maxPosition(groupId) + 1,
            )
            task.copy(id = taskDao.insert(task))
        } else {
            val existing = taskDao.getById(id) ?: return
            val position = if (existing.groupId == groupId) {
                existing.position
            } else {
                taskDao.maxPosition(groupId) + 1
            }
            val updated = existing.copy(
                groupId = groupId,
                title = cleanTitle,
                hour = h,
                minute = m,
                reminderEnabled = reminder,
                position = position,
            )
            taskDao.update(updated)
            updated
        }
        // Replaces any old alarm for this task (or cancels it when turned off).
        ReminderScheduler.schedule(context, saved)
    }

    suspend fun deleteTask(id: Long) {
        ReminderScheduler.cancel(context, id)
        NotificationHelper.cancel(context, id)
        taskDao.deleteById(id)
    }

    suspend fun moveTask(id: Long, up: Boolean) {
        db.withTransaction {
            val task = taskDao.getById(id) ?: return@withTransaction
            val list = taskDao.getByGroup(task.groupId).toMutableList()
            val from = list.indexOfFirst { it.id == id }
            val to = if (up) from - 1 else from + 1
            if (from < 0 || to !in list.indices) return@withTransaction
            val item = list.removeAt(from)
            list.add(to, item)
            taskDao.updateAll(list.mapIndexed { index, t -> t.copy(position = index) })
        }
    }

    suspend fun setDone(taskId: Long, date: LocalDate, done: Boolean) {
        if (done) {
            if (taskDao.getById(taskId) == null) return
            completionDao.insert(CompletionEntity(taskId = taskId, date = date.toString()))
            NotificationHelper.cancel(context, taskId)
        } else {
            completionDao.delete(taskId, date.toString())
        }
    }

    suspend fun isDone(taskId: Long, date: LocalDate): Boolean =
        completionDao.count(taskId, date.toString()) > 0

    /** Old checkmarks are not needed; keep the database small. */
    suspend fun pruneOldCompletions() {
        completionDao.deleteBefore(LocalDate.now().minusDays(60).toString())
    }

    companion object {
        @Volatile
        private var instance: Repository? = null

        fun get(context: Context): Repository =
            instance ?: synchronized(this) {
                instance ?: Repository(context.applicationContext).also { instance = it }
            }
    }
}
