package com.dailyflow.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }

class SettingsStore private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("dailyflow_settings", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(readTheme())
    val theme: StateFlow<ThemeMode> = _theme.asStateFlow()

    private val _sortByTime = MutableStateFlow(prefs.getBoolean(KEY_SORT, true))
    val sortByTime: StateFlow<Boolean> = _sortByTime.asStateFlow()

    var askedNotificationPermission: Boolean
        get() = prefs.getBoolean(KEY_ASKED_NOTIF, false)
        set(value) {
            prefs.edit().putBoolean(KEY_ASKED_NOTIF, value).apply()
        }

    fun setTheme(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME, mode.name).apply()
        _theme.value = mode
    }

    fun setSortByTime(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SORT, enabled).apply()
        _sortByTime.value = enabled
    }

    private fun readTheme(): ThemeMode {
        val stored = prefs.getString(KEY_THEME, null) ?: return ThemeMode.SYSTEM
        return ThemeMode.entries.firstOrNull { it.name == stored } ?: ThemeMode.SYSTEM
    }

    companion object {
        private const val KEY_THEME = "theme"
        private const val KEY_SORT = "sort_by_time"
        private const val KEY_ASKED_NOTIF = "asked_notification_permission"

        @Volatile
        private var instance: SettingsStore? = null

        fun get(context: Context): SettingsStore =
            instance ?: synchronized(this) {
                instance ?: SettingsStore(context.applicationContext).also { instance = it }
            }
    }
}
