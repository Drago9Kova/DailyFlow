# DailyFlow

A simple daily checklist for Android. Create tasks once; they repeat every day.
Checkmarks reset at midnight. Optional daily reminder notifications.

- Kotlin, Jetpack Compose, Material 3
- Room database (everything stays on the phone, works offline)
- Reminders: AlarmManager (setAndAllowWhileIdle) + WorkManager safety check every 6 hours
- Reminders restored after reboot, app update, time or time zone change

## Build
GitHub Actions builds it automatically on every push (`.github/workflows/build.yml`).
The APK appears under **Releases** (DailyFlow.apk) and under **Actions → run → Artifacts**.

Locally: `./gradlew assembleDebug` (JDK 17, Android SDK 35).

The project includes a fixed debug signing key (`app/dailyflow-debug.keystore`) so
new builds install over old ones without losing data. It is only for personal use.
